-- Cria o banco de dados
CREATE DATABASE IF NOT EXISTS minha_aplicacao;

-- Seleciona o banco de dados para uso
USE minha_aplicacao;
